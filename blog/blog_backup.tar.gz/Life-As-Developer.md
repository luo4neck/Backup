title: Life As Developer
date: 2015-06-02 21:23:51
categories: tech==技术
tags: life==生活
---

After been transferred into the new development team for a while, this is time to summarize the progress. 

First of all, it is quite happy to start coding in professional career. Senior developer is my career target in the coming 3-5 years. 

Secondly, the currently using programming language ABAP is a very funny one, according to wiki ABAP (Advanced Business Application Programming, originally Allgemeiner Berichts-Aufbereitungs-Prozessor, German for "general report creation processor") is a high-level programming language created by the German software company SAP. It is quite powerful for business processing and analysing. The internal table feature of ABAP is not only used for report generation, but also similar with STL in C++, which could inserting, appending, deleting, sorting, of structs or objects in one line. Not sure about the complexity of the operations now, but I will figure it out in the week. 

Thirdly, let me write some personal meaningless feelings. I am not sure it is because of the heavy training in HPC TCD or correct guy at correct position, after all my performance is higher than the average level of the team. Because my team have to working together with another team in Germany, we have to be in the meeting room 9:00am everyday to suit the 10:00am of Germany for daily phone meeting. Working time is not flexible at all, the only unhappy point at this moment. 

Lastly, I am considering to learning a functional programming language, have not made a decision among Haskell, Scala, Lisp and OCaml yet. Saw an idea from Zhihu that a good programmer should learn at least 3 languages, one OOP language, one FP language and one script language. I already did C++ for OOP and Python for script, now is the time to explore the world of FP. Another thing in mind is rewriting the GongZhu (could be found in my github) with some funny C++ features, for C++ practise. 

PS. Got the upgrading notification of new version 15.4 after I turned on Ubuntu in vm, looking forward what is new here. LOL.

2015 Summer (but as cold as winter), @Dublin. 
