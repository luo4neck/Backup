layout: photo
title: MPI and pthread Synchronization
date: 2014-11-30 23:35:58
categories: tech==技术
tags: tech
---

This is my first blog with a pic lol~

The following picture displays how could we synchronize all threads in a multi-process-multi-thread program. The structure is not complex and had been tested. 

![](/img/threads.png)

This idea came to me when I was coding my master degree graduation project but was not used in my final version. 

PS1, I just wrote a python script to backup all posts of this blog into github. The name of the repo is 'Backup', you can find it very easily. I am going to write about it later, maybe after some optimization on git part. 

PS2, I am using Ubuntu 14.04.1 LTS and the GUI has some bug (input $ lsb_release -a). When I click the panel, sometimes the Unity just dies.
