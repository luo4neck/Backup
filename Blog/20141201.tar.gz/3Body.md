title: 3Body
date: 2014-11-22 21:13:41
category: tech==技术
tags: tech
---

3Body is an independent program aims to simulate 3-body motion. This article will record the progress and fun points of the program. 

The structure of the program is Python but the simulation part is written in C++ to speed up. As a python beginner, hope this program could be a good practice. Following blocks are useful links on different topics, which I am planning to improve my ability in. 


/* ===================== Makefile Related Links ===================== */


/* ===================== Py<->C++ Related Links ===================== */


/* =====================  const   Related Links ===================== */

http://www.cnblogs.com/yc_sunniwell/archive/2010/07/14/1777416.html


/* ===================== C++ file Related Links ===================== */


/* ==================== hexo blog Related Links ===================== */

http://zipperary.com/2013/05/30/hexo-guide-4/


I am still learning how to use hexo lol.

2014 Winter, @Dublin
